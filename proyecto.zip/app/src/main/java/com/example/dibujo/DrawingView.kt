package com.example.dibujo

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class DrawingView(context: Context) : View(context) {

    class Layer(val name: String, w: Int, h: Int) {
        val bitmap: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        var visible = true
    }

    private class Pt(val x: Float, val y: Float, val p: Float)
    private class Snap(val layer: Int, val bitmap: Bitmap)

    companion object {
        const val W = 1200
        const val H = 1600
    }

    val layers = mutableListOf<Layer>()
    var active = 0
        private set
    var eraser = false
    var color = Color.BLACK
    var size = 14f
    var opacity = 1f
    var stabilizer = false
    var stabilizerStrength = 8
    var onLayersChanged: (() -> Unit)? = null

    private val strokeBmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    private val strokeCanvas = Canvas(strokeBmp)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val clearMode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    private val alphaPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val layerPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val bgPaint = Paint().apply { color = Color.rgb(90, 90, 90) }
    private val whitePaint = Paint().apply { color = Color.WHITE }

    // Vista (zoom y desplazamiento)
    private var fitScale = 1f
    private var scale = 1f
    private var offX = 0f
    private var offY = 0f
    private var gesturing = false
    private var lastFx = 0f
    private var lastFy = 0f
    private var lastDist = 0f

    // Trazo
    private var drawing = false
    private var pp: Pt? = null
    private var pr: Pt? = null
    private var sx = 0f
    private var sy = 0f
    private val undoStack = ArrayList<Snap>()
    private val redoStack = ArrayList<Snap>()

    init {
        addLayer()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        fitScale = min(w.toFloat() / W, h.toFloat() / H) * 0.98f
        resetView()
    }

    fun resetView() {
        scale = fitScale
        offX = (width - W * scale) / 2f
        offY = (height - H * scale) / 2f
        invalidate()
    }

    private fun toDocX(x: Float) = (x - offX) / scale
    private fun toDocY(y: Float) = (y - offY) / scale

    override fun onDraw(canvas: Canvas) {
        canvas.drawPaint(bgPaint)
        canvas.save()
        canvas.translate(offX, offY)
        canvas.scale(scale, scale)
        canvas.drawRect(0f, 0f, W.toFloat(), H.toFloat(), whitePaint)
        layers.forEachIndexed { i, l ->
            if (l.visible) {
                canvas.drawBitmap(l.bitmap, 0f, 0f, layerPaint)
                if (drawing && !eraser && i == active) {
                    alphaPaint.alpha = (opacity * 255).toInt()
                    canvas.drawBitmap(strokeBmp, 0f, 0f, alphaPaint)
                }
            }
        }
        canvas.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gesturing = false
                if (!layers[active].visible) return true
                saveUndo()
                drawing = true
                val x = toDocX(e.x)
                val y = toDocY(e.y)
                sx = x
                sy = y
                val p = Pt(x, y, pressureOf(e, e.pressure))
                pr = p
                pp = null
                prepare(p.p)
                target().drawPoint(p.x, p.y, paint)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2) {
                    cancelStroke()
                    gesturing = true
                    lastFx = (e.getX(0) + e.getX(1)) / 2f
                    lastFy = (e.getY(0) + e.getY(1)) / 2f
                    lastDist = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (gesturing) {
                    if (e.pointerCount >= 2) updateGesture(e)
                } else if (drawing) {
                    for (h in 0 until e.historySize) {
                        feed(e.getHistoricalX(h), e.getHistoricalY(h), e.getHistoricalPressure(h), e)
                    }
                    feed(e.x, e.y, e.pressure, e)
                }
            }
            MotionEvent.ACTION_UP -> {
                if (drawing && !gesturing) {
                    add(Pt(toDocX(e.x), toDocY(e.y), pressureOf(e, e.pressure)))
                }
                endStroke()
                gesturing = false
            }
            MotionEvent.ACTION_CANCEL -> {
                endStroke()
                gesturing = false
            }
        }
        invalidate()
        return true
    }

    // ---- Zoom y desplazamiento con dos dedos ----
    private fun updateGesture(e: MotionEvent) {
        val fx = (e.getX(0) + e.getX(1)) / 2f
        val fy = (e.getY(0) + e.getY(1)) / 2f
        val d = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
        var k = 1f
        if (lastDist > 0f && d > 0f) {
            val ns = (scale * d / lastDist).coerceIn(fitScale * 0.5f, fitScale * 20f)
            k = ns / scale
            scale = ns
        }
        offX = fx - (lastFx - offX) * k
        offY = fy - (lastFy - offY) * k
        lastFx = fx
        lastFy = fy
        lastDist = d
    }

    // ---- Trazo ----
    private fun pressureOf(e: MotionEvent, press: Float): Float =
        if (e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS) press else 1f

    private fun feed(x: Float, y: Float, press: Float, e: MotionEvent) {
        val dx = toDocX(x)
        val dy = toDocY(y)
        if (stabilizer) {
            val k = 1f / (1f + stabilizerStrength * 0.5f)
            sx += (dx - sx) * k
            sy += (dy - sy) * k
        } else {
            sx = dx
            sy = dy
        }
        add(Pt(sx, sy, pressureOf(e, press)))
    }

    private fun target(): Canvas = if (eraser) layers[active].canvas else strokeCanvas

    private fun prepare(pressure: Float) {
        paint.strokeWidth = size * max(0.15f, pressure)
        if (eraser) {
            paint.xfermode = clearMode
            paint.color = Color.BLACK
        } else {
            paint.xfermode = null
            paint.color = color or (0xFF shl 24)
        }
    }

    private fun add(c: Pt) {
        val r = pr ?: return
        prepare(c.p)
        val path = Path()
        val q = pp
        if (q == null) {
            path.moveTo(r.x, r.y)
            path.lineTo(c.x, c.y)
        } else {
            path.moveTo((q.x + r.x) / 2f, (q.y + r.y) / 2f)
            path.quadTo(r.x, r.y, (r.x + c.x) / 2f, (r.y + c.y) / 2f)
        }
        target().drawPath(path, paint)
        pp = r
        pr = c
    }

    private fun endStroke() {
        if (!drawing) return
        drawing = false
        if (!eraser) {
            alphaPaint.alpha = (opacity * 255).toInt()
            layers[active].canvas.drawBitmap(strokeBmp, 0f, 0f, alphaPaint)
        }
        strokeCanvas.drawColor(0, PorterDuff.Mode.CLEAR)
        pp = null
        pr = null
    }

    /** Si entra un segundo dedo, se descarta el trazo en curso. */
    private fun cancelStroke() {
        if (!drawing) return
        drawing = false
        strokeCanvas.drawColor(0, PorterDuff.Mode.CLEAR)
        if (undoStack.isNotEmpty()) {
            restore(undoStack.removeAt(undoStack.size - 1))
        }
        pp = null
        pr = null
    }

    // ---- Deshacer / rehacer ----
    private fun snap(i: Int) = Snap(i, layers[i].bitmap.copy(Bitmap.Config.ARGB_8888, false))

    private fun saveUndo() {
        undoStack.add(snap(active))
        if (undoStack.size > 8) undoStack.removeAt(0)
        redoStack.clear()
    }

    private fun restore(s: Snap) {
        val l = layers[s.layer]
        l.canvas.drawColor(0, PorterDuff.Mode.CLEAR)
        l.canvas.drawBitmap(s.bitmap, 0f, 0f, null)
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val s = undoStack.removeAt(undoStack.size - 1)
        redoStack.add(snap(s.layer))
        restore(s)
        invalidate()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val s = redoStack.removeAt(redoStack.size - 1)
        undoStack.add(snap(s.layer))
        restore(s)
        invalidate()
    }

    // ---- Capas ----
    fun addLayer() {
        if (layers.size >= 6) return
        layers.add(Layer("Capa ${layers.size + 1}", W, H))
        active = layers.size - 1
        onLayersChanged?.invoke()
    }

    fun select(i: Int) {
        active = i
        onLayersChanged?.invoke()
    }

    fun toggleVisible(i: Int) {
        layers[i].visible = !layers[i].visible
        invalidate()
        onLayersChanged?.invoke()
    }

    fun clearLayer() {
        saveUndo()
        layers[active].canvas.drawColor(0, PorterDuff.Mode.CLEAR)
        invalidate()
    }

    fun exportBitmap(): Bitmap {
        val b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.WHITE)
        for (l in layers) if (l.visible) c.drawBitmap(l.bitmap, 0f, 0f, null)
        return b
    }
}
