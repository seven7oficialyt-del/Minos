package com.example.dibujo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

class ColorWheelView(context: Context) : View(context) {

    var hue = 0f
        private set
    var sat = 0f
        private set
    var value = 1f
        private set
    var onChange: ((Int) -> Unit)? = null

    private val huePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val satPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val darkPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val markWhite = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.WHITE
    }
    private val markBlack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = Color.BLACK
    }
    private var cx = 0f
    private var cy = 0f
    private var radius = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cx = w / 2f
        cy = h / 2f
        radius = min(w, h) / 2f - 8f
        huePaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED),
            null
        )
        satPaint.shader = RadialGradient(cx, cy, radius, Color.WHITE, 0x00FFFFFF, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawCircle(cx, cy, radius, huePaint)
        canvas.drawCircle(cx, cy, radius, satPaint)
        darkPaint.color = Color.argb(((1f - value) * 255).toInt(), 0, 0, 0)
        canvas.drawCircle(cx, cy, radius, darkPaint)
        val a = Math.toRadians(hue.toDouble())
        val mx = cx + (cos(a) * sat * radius).toFloat()
        val my = cy + (sin(a) * sat * radius).toFloat()
        canvas.drawCircle(mx, my, 16f, markWhite)
        canvas.drawCircle(mx, my, 16f, markBlack)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            val dx = e.x - cx
            val dy = e.y - cy
            sat = min(1f, hypot(dx, dy) / radius)
            var h = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
            if (h < 0f) h += 360f
            hue = h
            invalidate()
            notifyChange()
        }
        return true
    }

    private fun notifyChange() {
        onChange?.invoke(Color.HSVToColor(floatArrayOf(hue, sat, value)))
    }

    /** Coloca la rueda en un color sin avisar a onChange. */
    fun setColor(c: Int) {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hue = hsv[0]
        sat = hsv[1]
        value = hsv[2]
        invalidate()
    }

    fun setBrightness(v: Float) {
        value = v
        invalidate()
        notifyChange()
    }
}
