package com.example.dibujo

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.widget.doAfterTextChanged
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private lateinit var drawing: DrawingView
    private lateinit var layerBox: LinearLayout
    private lateinit var bBrush: Button
    private lateinit var bEraser: Button
    private lateinit var currentColor: View
    private var dp = 1f

    private val palette = listOf(
        "#000000", "#555555", "#999999", "#FFFFFF",
        "#E53935", "#8E0000", "#FB8C00", "#FDD835", "#C0CA33",
        "#43A047", "#1B5E20", "#00ACC1", "#4FC3F7", "#1E88E5", "#0D2A6B",
        "#8E24AA", "#EC407A", "#F8BBD0", "#6D4C41", "#F1C27D"
    ).map { Color.parseColor(it) }

    private fun px(v: Int) = (v * dp).toInt()

    private fun swatchBg(c: Int) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = px(8).toFloat()
        setStroke(px(1), Color.GRAY)
    }

    private fun hexOf(c: Int) = String.format("#%06X", 0xFFFFFF and c)

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun seekListener(onChange: (Int, Boolean) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, v: Int, fromUser: Boolean) = onChange(v, fromUser)
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        }

    private fun slider(label: String, maxValue: Int, start: Int, onChange: (Int) -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(12), 0, px(12), 0)
            addView(TextView(context).apply {
                text = label
                minWidth = px(80)
            })
            addView(SeekBar(context).apply {
                max = maxValue
                progress = start
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnSeekBarChangeListener(seekListener { v, _ -> onChange(v) })
            })
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dp = resources.displayMetrics.density
        drawing = DrawingView(this)

        // Herramientas
        bBrush = button("Pincel") { setTool(false) }
        bEraser = button("Goma") { setTool(true) }
        val toolRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(bBrush)
            addView(bEraser)
            addView(button("Deshacer") { drawing.undo() })
            addView(button("Rehacer") { drawing.redo() })
            addView(button("Limpiar") { drawing.clearLayer() })
            addView(button("Encajar") { drawing.resetView() })
            addView(button("Guardar") { save() })
        }
        val toolScroll = HorizontalScrollView(this).apply { addView(toolRow) }

        // Colores: muestra del color actual + paleta
        currentColor = View(this).apply {
            background = swatchBg(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(px(44), px(44)).apply {
                setMargins(px(8), px(4), px(8), px(4))
            }
            setOnClickListener { showColorDialog() }
        }
        val paletteBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        for (c in palette) {
            paletteBox.addView(View(this).apply {
                background = swatchBg(c)
                layoutParams = LinearLayout.LayoutParams(px(36), px(36)).apply {
                    setMargins(px(4), 0, px(4), 0)
                }
                setOnClickListener { setColor(c) }
            })
        }
        val colorRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(currentColor)
            addView(HorizontalScrollView(context).apply {
                addView(paletteBox)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
        }

        // Estabilizador
        val stabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(12), 0, px(12), 0)
            addView(SwitchCompat(context).apply {
                text = "Estabilizador"
                setOnCheckedChangeListener { _, on -> drawing.stabilizer = on }
            })
            addView(SeekBar(context).apply {
                max = 20
                progress = 8
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnSeekBarChangeListener(seekListener { v, _ -> drawing.stabilizerStrength = max(1, v) })
            })
        }

        // Capas
        layerBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val layerScroll = HorizontalScrollView(this).apply {
            addView(layerBox)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val layersRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(layerScroll)
            addView(button("+ Capa") { drawing.addLayer() })
        }
        val hint = TextView(this).apply {
            text = "Dos dedos: zoom y mover. Capas: toca para elegir, mantén pulsado para ocultar."
            textSize = 11f
            setPadding(px(12), 0, px(12), px(4))
        }

        drawing.onLayersChanged = { refreshLayers() }
        refreshLayers()
        setTool(false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            addView(toolScroll)
            addView(colorRow)
            addView(slider("Tamaño", 80, 14) { drawing.size = max(1, it).toFloat() })
            addView(slider("Opacidad", 100, 100) { drawing.opacity = max(5, it) / 100f })
            addView(stabRow)
            addView(drawing, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(layersRow)
            addView(hint)
        }
        setContentView(root)
    }

    private fun setTool(eraser: Boolean) {
        drawing.eraser = eraser
        bBrush.alpha = if (eraser) 0.5f else 1f
        bEraser.alpha = if (eraser) 1f else 0.5f
    }

    private fun setColor(c: Int) {
        drawing.color = c
        currentColor.background = swatchBg(c)
        setTool(false)
    }

    private fun refreshLayers() {
        layerBox.removeAllViews()
        drawing.layers.forEachIndexed { i, l ->
            layerBox.addView(Button(this).apply {
                text = (if (l.visible) "👁 " else "🚫 ") + l.name
                isAllCaps = false
                alpha = if (i == drawing.active) 1f else 0.5f
                setOnClickListener { drawing.select(i) }
                setOnLongClickListener {
                    drawing.toggleVisible(i)
                    true
                }
            })
        }
    }

    // ---- Selector de color: rueda + brillo + código hexadecimal ----
    private fun showColorDialog() {
        var chosen = drawing.color
        var updating = false

        val preview = View(this).apply {
            background = swatchBg(chosen)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(40))
        }
        val wheel = ColorWheelView(this).apply {
            setColor(chosen)
            layoutParams = LinearLayout.LayoutParams(px(260), px(260)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setMargins(0, px(12), 0, px(12))
            }
        }
        val bright = SeekBar(this).apply {
            max = 100
            progress = (wheel.value * 100).toInt()
        }
        val hex = EditText(this).apply {
            hint = "#RRGGBB"
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            filters = arrayOf(InputFilter.LengthFilter(7))
            setText(hexOf(chosen))
        }

        wheel.onChange = { c ->
            chosen = c
            preview.background = swatchBg(c)
            updating = true
            hex.setText(hexOf(c))
            updating = false
        }
        bright.setOnSeekBarChangeListener(seekListener { v, fromUser ->
            if (fromUser) wheel.setBrightness(v / 100f)
        })
        hex.doAfterTextChanged { t ->
            if (!updating) {
                val s = t.toString().trim().removePrefix("#")
                if (s.length == 6) {
                    try {
                        val c = Color.parseColor("#" + s)
                        chosen = c
                        wheel.setColor(c)
                        bright.progress = (wheel.value * 100).toInt()
                        preview.background = swatchBg(c)
                    } catch (ex: IllegalArgumentException) {
                    }
                }
            }
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(12), px(20), px(8))
            addView(preview)
            addView(wheel)
            addView(TextView(context).apply { text = "Brillo" })
            addView(bright)
            addView(hex)
        }
        AlertDialog.Builder(this)
            .setTitle("Elegir color")
            .setView(ScrollView(this).apply { addView(content) })
            .setPositiveButton("Usar") { _, _ -> setColor(chosen) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun save() {
        val bmp = drawing.exportBitmap()
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "dibujo_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Dibujo")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Guardado en Imágenes/Dibujo", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "No se pudo guardar", Toast.LENGTH_SHORT).show()
        }
    }
}
